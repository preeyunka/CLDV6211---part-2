using Microsoft.AspNetCore.Mvc;

namespace KhumaloCraft.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AboutUs()
        {
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }

        public ActionResult MyWork()
        {
            return View();
        }

        // Add Privacy action
        public ActionResult Privacy()
        {
            return View();
        }

        public ActionResult FAQ()
        {
            return View();
        }
    }
}

