﻿using Microsoft.AspNetCore.Mvc;

namespace KhumaloCraft.Controllers
{
    public class MyWorkController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
